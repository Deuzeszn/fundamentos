productos = {}
def registrar_producto():
    while True:
        codigo = input("Ingrese codigo del producto : ")
        if codigo in productos:
            print("El codigo ya esta registrado")
        else:
            break
    while True:
        nombre = input("Ingrese nombre del producto: ")
        if len(nombre) <3 :
            print("El nombre debe tener al menos 3 letras, intente de nuevo")
        else:
            break

    while True:
        try:
            stock = int(input("Ingrese stock: "))
            if stock <0:
                print("El stock debe ser mayor a 0")
            else:
                break
        except ValueError:
            print("Debe ingresar un numero entero, intente nuevamente")
    while True:
        try:
            precio = float(input("Ingrese el precio"))
            if precio <= 0:
                print("El precio debe ser mayor a 0")
            else:
                break
        except ValueError:
            print("Debe ingresar numero valido, Porfavor intente denuevo")
print("Producto registrado con exito")

def listar_productos():
    print("---Productos con stock---")
encontrados = False
for codigo, datos in productos.items():
    if datos("Stock") > 0:
        print(f"Codigo : {codigo}, nombre: {datos["nombre"]}, stock: {datos["stock"]}, precio: ${datos["precio"]}")
        encontrados = True
if not encontrados:
    print("No hay productos en stock")
    
def eliminar_prod():
    codigo = input("Ingrese el codigo del producto a eliminar: ")
    if codigo in productos:
        del productos[codigo]
        print("Producto eliminado correctamente")
    else:
        print("Error, codigo no encontrado")

def menu():
    while True:
        print("""----MENU PRINCIPAL---- 
              1. Registrar producto.
              2. Listar producto.
              3. Eliminar producto
              4. Salir      """)
        opcion = input("Ingrese opcion:")
        if opcion == 1:
            registrar_producto()
        elif opcion == 2:
            listar_productos()
        elif opcion == 3:
            eliminar_prod()
        elif opcion == 4:
            print("Saliendo del programa")
            break
        else:
            print("Opcion no valida, Porfavor intentelo de nuevo")

menu()