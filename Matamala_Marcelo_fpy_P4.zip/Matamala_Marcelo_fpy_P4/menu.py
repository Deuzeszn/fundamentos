import registrodeproductos
def menu():
    while True:
        print("""----MENU PRINCIPAL---- 
              1. Registrar producto.
              2. Listar producto.
              3. Eliminar producto
              4. Salir      """)
        opcion = input("Ingrese opcion:")
        if opcion == 1:
            registrar_producto()
        elif opcion == 2:
            listar_productos()
        elif opcion == 3:
            eliminar_prod()
        elif opcion == 4:
            print("Saliendo del programa")
            break
        else:
            print("Opcion no valida, Porfavor intentelo de nuevo")
menu()                 
